# Glamour

A casual introduction. 你好世界！

## Let's talk about artichokes

The artichoke is mentioned as a garden
plant in the 8th century BC by Homer
and Hesiod. The naturally occurring
variant of the artichoke, the cardoon,
which is native to the Mediterranean
area, also has records of use as a
food among the ancient Greeks and
Romans. Pliny the Elder mentioned
growing of 'carduus' in Carthage
and Cordoba.

He holds him with his skinny hand,
There was ship,' quoth he.
'Hold off! unhand me, grey-beard loon!'
An artichoke dropt he.

## Other foods worth mentioning

1. Carrots
2. Celery
3. Tacos
• Soft
• Hard
4. Cucumber

## Things to eat today

* Carrots
* Ramen
* Currywurst
